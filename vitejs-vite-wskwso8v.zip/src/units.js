const UNIT_DEFS = {
  player:{maxHP:100000, atk:200, def:10, move:10, range:500, faction:"ally"},
  enemy:{maxHP:60, atk:15, def:5, move:3, range:1, faction:"enemy"}
};

function createUnit(type,x,y){
  const d=UNIT_DEFS[type];
  return {
    ...d,
    x,y,
    hp:d.maxHP,
    acted:false,
    moveDone:false
  };
}

function getSpawn(map,w,h,units){
  while(true){
    const x=Math.floor(Math.random()*w);
    const y=Math.floor(Math.random()*h);
    if(map[x][y]!==0)continue;
    if(units.some(u=>u.x===x&&u.y===y))continue;
    return {x,y};
  }
}