const canvas=document.getElementById("game");
const ctx=canvas.getContext("2d");
canvas.width=800; canvas.height=600;

const tileW=64, tileH=32;

// ===== マップ =====
let world, map, mapW, mapH;

// ===== ユニット =====
let units=[], player;

// ===== エフェクト =====
let damageTexts=[];

// ===== 状態 =====
let selected=null;
let moveTiles=[];
let turn="player";
let gameOver=false;
let resultText="";

// ===== 初期化 =====
function init(){
  world=generateMap();
  map=world.map; mapW=world.w; mapH=world.h;

  units=[];
  const pSpawn=getSpawn(map,mapW,mapH,units);
  player=createUnit("player",pSpawn.x,pSpawn.y);
  units.push(player);

  for(let i=0;i<3;i++){
    const s=getSpawn(map,mapW,mapH,units);
    units.push(createUnit("enemy",s.x,s.y));
  }

  units.forEach(u=>{
    u.acted=false;
    u.moveCommitted=false;
    u.renderX=u.x;
    u.renderY=u.y;
    u.shake=0;
    u.flash=0;
  });

  selected=null;
  moveTiles=[];
  turn="player";
  gameOver=false;
}

init();

// ===== 座標 =====
function gridToScreenRaw(x,y){
  return {x:(x-y)*tileW/2+400,y:(x+y)*tileH/2+100};
}
function gridToScreen(x,y){
  const p=gridToScreenRaw(x,y);
  return worldToScreen(p.x,p.y);
}
function screenToGrid(px,py){
  const w=screenToWorld(px,py);
  const x=(w.x-400)/(tileW/2);
  const y=(w.y-100)/(tileH/2);
  return {x:Math.floor((x+y)/2),y:Math.floor((y-x)/2)};
}

// ===== BFS移動 =====
function getMoveTiles(unit){
  const visited=new Set();
  const result=[];
  const q=[{x:unit.x,y:unit.y,d:0}];

  while(q.length){
    const {x,y,d}=q.shift();
    const key=`${x},${y}`;
    if(visited.has(key))continue;
    visited.add(key);

    if(d>unit.move)continue;

    result.push({x,y});

    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nx=x+dx, ny=y+dy;
      if(nx<0||ny<0||nx>=mapW||ny>=mapH)continue;
      if(map[nx][ny]!==0)continue;
      if(units.some(u=>u.x===nx&&u.y===ny && !(nx===unit.x&&ny===unit.y)))continue;
      q.push({x:nx,y:ny,d:d+1});
    }
  }
  return result;
}

// ===== 入力 =====
canvas.addEventListener("click",e=>{
  if(turn!=="player"||gameOver)return;

  const r=canvas.getBoundingClientRect();
  const g=screenToGrid(e.clientX-r.left,e.clientY-r.top);
  const clicked=units.find(u=>u.x===g.x&&u.y===g.y);

  if(clicked && clicked.faction==="ally"){
    if(clicked.acted)return;
    if(selected!==clicked){
      selected=clicked;
      moveTiles=getMoveTiles(selected);
    }
    return;
  }

  if(!selected)return;

  // 攻撃
  if(clicked && clicked.faction==="enemy"){
    const dist=Math.abs(selected.x-g.x)+Math.abs(selected.y-g.y);
    if(dist<=selected.range){
      applyDamage(clicked,selected);
      selected.acted=true;
      selected.moveCommitted=true;
      endTurn();
    }
    return;
  }

  // 移動（アニメ）
  if(!selected.moveCommitted){
    const ok=moveTiles.some(t=>t.x===g.x&&t.y===g.y);
    if(ok){
      selected.x=g.x;
      selected.y=g.y;
    }
  }
});

// ===== ダメージ処理 =====
function applyDamage(target,attacker){
  const dmg=Math.max(1,attacker.atk-target.def*0.3);
  target.hp-=dmg;

  target.flash=10;
  target.shake=10;

  damageTexts.push({
    x:target.x,y:target.y,value:Math.floor(dmg),life:60
  });

  if(target.hp<=0){
    units=units.filter(u=>u!==target);
  }
}

// ===== ターン =====
function endTurn(){
  selected=null;
  moveTiles=[];

  if(units.filter(u=>u.faction==="ally"&&!u.acted).length===0){
    enemyTurn();
  }
}

function enemyTurn(){
  turn="enemy";

  units.filter(u=>u.faction==="enemy")
    .forEach(e=>enemyAct(e,player,map,mapW,mapH,units));

  units.forEach(u=>{
    u.acted=false;
    u.moveCommitted=false;
  });

  turn="player";
}

// ===== 勝敗 =====
function checkGameOver(){
  const enemies=units.filter(u=>u.faction==="enemy");
  if(player.hp<=0){
    gameOver=true;
    resultText="敗北";
  }
  if(enemies.length===0){
    gameOver=true;
    resultText="勝利";
  }
}

// ===== 描画 =====
function drawTile(x,y){
  const p=gridToScreen(x,y);
  ctx.beginPath();
  ctx.moveTo(p.x,p.y);
  ctx.lineTo(p.x+tileW/2,p.y+tileH/2);
  ctx.lineTo(p.x,p.y+tileH);
  ctx.lineTo(p.x-tileW/2,p.y+tileH/2);
  ctx.closePath();
  ctx.fillStyle=map[x][y]===0?"#222":"#555";
  ctx.fill();
}

function drawMove(){
  moveTiles.forEach(t=>{
    const p=gridToScreen(t.x,t.y);
    ctx.beginPath();
    ctx.moveTo(p.x,p.y);
    ctx.lineTo(p.x+tileW/2,p.y+tileH/2);
    ctx.lineTo(p.x,p.y+tileH);
    ctx.lineTo(p.x-tileW/2,p.y+tileH/2);
    ctx.closePath();
    ctx.fillStyle="rgba(0,0,255,0.3)";
    ctx.fill();
  });
}

function drawUnits(){
  units.forEach(u=>{
    // アニメ補間
    u.renderX += (u.x-u.renderX)*0.2;
    u.renderY += (u.y-u.renderY)*0.2;

    const p=gridToScreen(u.renderX,u.renderY);

    let shakeX=0, shakeY=0;
    if(u.shake>0){
      shakeX=(Math.random()-0.5)*4;
      shakeY=(Math.random()-0.5)*4;
      u.shake--;
    }

    ctx.fillStyle=u.faction==="ally"?"red":"cyan";
    ctx.beginPath();
    ctx.arc(p.x+shakeX,p.y+tileH/2+shakeY,8,0,Math.PI*2);
    ctx.fill();

    // 赤フラッシュ
    if(u.flash>0){
      ctx.fillStyle="rgba(255,0,0,0.3)";
      ctx.beginPath();
      ctx.arc(p.x,p.y+tileH/2,10,0,Math.PI*2);
      ctx.fill();
      u.flash--;
    }

    // HPバー
    const ratio=u.hp/u.maxHP;
    ctx.fillStyle="black";
    ctx.fillRect(p.x-15,p.y+20,30,4);
    ctx.fillStyle="lime";
    ctx.fillRect(p.x-15,p.y+20,30*ratio,4);
  });
}

function drawDamage(){
  damageTexts.forEach(d=>{
    const p=gridToScreen(d.x,d.y);
    ctx.fillStyle="yellow";
    ctx.fillText(d.value,p.x,p.y-20-(60-d.life));
    d.life--;
  });
  damageTexts=damageTexts.filter(d=>d.life>0);
}

function drawUI(){
  ctx.fillStyle="white";
  ctx.fillText(turn==="player"?"PLAYER TURN":"ENEMY TURN",10,20);
}

function drawResult(){
  if(!gameOver)return;

  ctx.fillStyle="rgba(0,0,0,0.7)";
  ctx.fillRect(0,0,canvas.width,canvas.height);

  ctx.fillStyle="white";
  ctx.font="40px sans-serif";
  ctx.fillText(resultText,350,250);

  ctx.font="20px sans-serif";
  ctx.fillText("クリックでリトライ",320,300);
}

// ===== クリックでリトライ =====
canvas.addEventListener("click",()=>{
  if(gameOver){
    init();
  }
});

// ===== ループ =====
function draw(){
  updateCamera();
  ctx.fillRect(0,0,canvas.width,canvas.height);

  for(let x=0;x<mapW;x++){
    for(let y=0;y<mapH;y++){
      drawTile(x,y);
    }
  }

  if(selected)drawMove();
  drawUnits();
  drawDamage();
  drawUI();

  checkGameOver();
  drawResult();
}

function loop(){
  draw();
  requestAnimationFrame(loop);
}
loop();

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js");
}