const camera = { x:0, y:0, target:null };

function setCameraTarget(u){ camera.target=u; }

function updateCamera(){
  if(!camera.target)return;
  const p = gridToScreenRaw(camera.target.x, camera.target.y);
  camera.x += (p.x - canvas.width/2 - camera.x)*0.1;
  camera.y += (p.y - canvas.height/2 - camera.y)*0.1;
}

function worldToScreen(x,y){ return {x:x-camera.x,y:y-camera.y}; }
function screenToWorld(x,y){ return {x:x+camera.x,y:y+camera.y}; }