function enemyAct(e, player, map, w, h, units){
  if(player.hp<=0)return;

  const dist=Math.abs(e.x-player.x)+Math.abs(e.y-player.y);

  if(dist<=1){
    player.hp -= Math.max(1, e.atk - player.def*0.3);
    return;
  }

  const dx=Math.sign(player.x-e.x);
  const dy=Math.sign(player.y-e.y);

  const nx=e.x+dx, ny=e.y+dy;

  if(nx>=0&&ny>=0&&nx<w&&ny<h&&map[nx][ny]===0
    && !units.some(u=>u.x===nx&&u.y===ny)){
      e.x=nx; e.y=ny;
  }
}