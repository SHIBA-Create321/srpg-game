function createEmptyMap(w, h) {
  const map = [];
  for (let x = 0; x < w; x++) {
    map[x] = [];
    for (let y = 0; y < h; y++) {
      map[x][y] = 1;
    }
  }
  return map;
}

function generateMap() {
  const w = 29;
  const h = 24;
  const map = createEmptyMap(w, h);

  let x = 6, y = 6;

  for (let i = 0; i < 400; i++) {
    map[x][y] = 0;
    const d = Math.floor(Math.random()*4);
    if (d===0)x++; if (d===1)x--; if (d===2)y++; if (d===3)y--;
    x = Math.max(1, Math.min(w-2,x));
    y = Math.max(1, Math.min(h-2,y));
  }

  return { map, w, h };
}