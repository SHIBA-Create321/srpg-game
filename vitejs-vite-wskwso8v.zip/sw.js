self.addEventListener("install", e => {
  e.waitUntil(
    caches.open("game-cache").then(cache => {
      return cache.addAll([
        "./",
        "./index.html",
        "./src/main.js",
        "./src/map.js",
        "./src/units.js",
        "./src/ai.js",
        "./src/camera.js"
      ]);
    })
  );
});

self.addEventListener("fetch", e => {
  e.respondWith(
    caches.match(e.request).then(res => res || fetch(e.request))
  );
});