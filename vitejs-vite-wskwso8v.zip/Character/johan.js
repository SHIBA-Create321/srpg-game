const Johan_Egbert = {
  // =========================
  // 基本情報
  // =========================
  name: "ヨハン・エグバート",
  rarity: "SSR",
  faction: "聖教導騎士団・異端審問局",
  originTags: ["孤児", "聖職者", "実験体"],
  ideologyTags: ["献身", "秩序", "自己犠牲"],

  // =========================
  // 戦闘基本
  // =========================
  job: "パラディン（重装支援型）",
  attribute: {
    normal: "光",
    corrupted: "闇"
  },

  maxHP: 4200,
  atk: 850,
  def: 1200,
  speed: 85,
  move: 3,
  range: 1,

  // =========================
  // スキル
  // =========================

  normalAttack: {
    name: "断罪のメイス",
    effect(unit, target) {
      const dmg = unit.atk;
      target.hp -= dmg;

      const heal = unit.def * 0.1;
      unit.hp = Math.min(unit.maxHP, unit.hp + heal);
    }
  },

  skill1: {
    name: "聖域の残光",
    ct: 3,
    range: 2,

    effect(unit, allies) {
      allies.forEach(a => {
        a.shield = (a.shield || 0) + 0.25;
        a.status = a.status || {};
        a.status.debuffClean = true;
      });
    }
  },

  skill2: {
    name: "裁きの鉄槌",
    ct: 4,
    range: 2,
    condition(unit, state) {
      return state.lastAllyHitBySkill1 === true;
    },

    effect(unit, target) {
      const dmg = unit.atk * 2.5;
      target.hp -= dmg;
      target.stunned = true;
    }
  },

  // =========================
  // パッシブ
  // =========================
  passive: {
    faithBarrier(unit, state) {
      if (unit.hp / unit.maxHP >= 0.5) {
        unit.def *= 1.2;
      }
    },

    martyrBlood(unit) {
      unit.faithStack = (unit.faithStack || 0) + 1;
      unit.healBoost = (unit.faithStack || 0) * 0.03;
    },

    silentMadness(unit) {
      unit.atk *= 1 + (unit.erosionLevel * 0.1);
      unit.def *= 1 - (unit.erosionLevel * 0.05);
    }
  },

  // =========================
  // 侵食
  // =========================
  erosion: {
    level: 0,

    trigger(unit, context) {
      if (unit.hp <= unit.maxHP * 0.3 || context.allyDead) {
        this.level++;
      }
    },

    apply(unit) {
      if (this.level === 1) {
        unit.atk *= 1.1;
      }

      if (this.level === 2) {
        unit.move += 1;
      }

      if (this.level === 3) {
        unit.attribute.current = "闇";
        unit.controlLoss = 0.3;
      }

      if (this.level >= 4) {
        unit.autoBattle = true;
        unit.berserk = true;
      }
    }
  },

  // =========================
  // 裏切り
  // =========================
  betrayal: {
    trigger(unit, state) {
      return unit.erosion.level >= 4 && state.turns >= 3;
    },

    transform(unit) {
      return {
        name: "堕ちた執行者ヨハン",
        hp: unit.maxHP,
        atk: unit.atk * 1.5,
        def: unit.def * 0.5,
        behavior: "enemy",
        skills: ["dark_prison"]
      };
    }
  },

  // =========================
  // 好感度
  // =========================
  affinity: {
    value: 0,

    erosionReduction: 0.2,

    lowPenalty(unit) {
      if (this.value < 0) {
        unit.buffDisabled = true;
      }
    }
  },

  // =========================
  // 精神
  // =========================
  psyche: {
    stability: 40,
    erosionResist: 0.3,
    betrayalResist: 0.5
  },

  // =========================
  // 装備
  // =========================
  equipment: {
    type: ["重鎧", "鈍器", "聖印"],
    special: "古びたロザリオ"
  },

  // =========================
  // 表現用
  // =========================
  lore: {
    summary:
      "旧教会の実験体として生まれた聖騎士。献身と狂気の境界に立つ存在。",

    erosionVisual:
      "瞳の光が消え、聖痕から黒い液体が溢れる",

    betrayalVisual:
      "救済の名のもとに味方を殲滅する存在へ変貌"
  }
};